<?php include "include/header.php"; ?>

<!-- key objective starts here -->
<div class="row k_inbanner">
	<img src="images/baner1.jpg" alt="">
</div>
<div class="row dum_container key_div">
	
	<div class="k_cheading">
		<h1>Confirmed <span class="k_greencolor">Utilities</span> </h1>
		<img src="images/kborder_bottom.png" alt="">
	</div>
	<p>

<br>
	<ul class="k_confirmed_als">
		<li><a href="http://www.hescom.co.in/" target="_blank"><img src="images/kp1.jpg">
		HUBLI ELECTRICITY SUPPLY COMPANY LIMITED
		</a>
		<li><a href="https://www.mescom.org.in/SCP/Myhome.aspx" target="_blank"><img src="images/kp2.jpg">MESCOM R-APDRP Portal</a></li>
		<li><a href="http://www.kptcl.com/" target="_blank"><img src="images/kp3.jpg">Karnataka Power Transmission Corporation</a></li>
		<li><a href="http://www.gescom.in/" target="_blank"><img src="images/kp4.jpg">Gulbarga Electricity Supply Company Limited</a></li>
		<li><a href="http://www.cescmysore.org/en/" target="_blank"><img src="images/kp5.jpg">Chamundeshwari Electricity Supply Corporation Limited</a></li>
		<li><a href="http://uhbvn.org.in/web/portal/home" target="_blank"><img src="images/logo1.jpg">Uttar Haryana Bijli Vitran Nigam Limited</a></li>
		<li><a href="http://www.dhbvn.org.in/web/portal/home" target="_blank"><img src="images/logo2.jpg"> Dakshin Haryana Bijli Vitran Nigam</a></li>
		<li><a href="http://www.mpez.co.in/portal/Jabalpur_home.portal" target="_blank"><img src="images/logo3.jpg" style="border: 2px solid #aeb4b2;">Madhya Pradesh Poorv Kshetra Vidyut Vitaran Company Ltd.</a></li>
		<li><a href="http://www.mahadiscom.in/" target="_blank"><img src="images/logo4.jpg" style="border: 2px solid #aeb4b2;">Maharashtra State Electricity Distribution Co. Ltd</a></li>
		<li><a href="http://www.pgvcl.com/" target="_blank"><img src="images/logo5.jpg" style="border: 2px solid #aeb4b2;">Paschim Gujarat Vij. Co. Ltd</a></li>
		<li><a href="http://www.mgvcl.com/payonline.php" target="_blank"><img src="images/logo6.jpg" style="border: 2px solid #aeb4b2;">Madhya Gujarat Vij. Co. Ltd</a></li>
		<li><a href="http://www.bsesdelhi.com/HTML/index.html" target="_blank"><img src="images/logo7.jpg" style="border: 2px solid #aeb4b2;">BSES</a></li>
		<li><a href="https://www.tatapower.com/" target="_blank"><img src="images/logo8.jpg" style="border: 2px solid #aeb4b2;">Tata Power </a></li>
		<li><a href="http://tatapower-ddl.com/" target="_blank"><img src="images/logo13.jpg" style="border: 2px solid #aeb4b2;">TATA POWER DELHI DISTRIBUTION LIMITED</a></li>
		<li><a href="https://www.epri.com/#/" target="_blank"><img src="images/kp18.jpg" style="border: 2px solid #aeb4b2;">electric power research institute</a></li>
	</ul>
	</p>
</div>




<!-- key objective ends here -->

<?php include "include/footer.php"; ?>